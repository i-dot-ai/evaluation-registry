import './style/main.scss'
import { initAll } from 'govuk-frontend'

initAll()
